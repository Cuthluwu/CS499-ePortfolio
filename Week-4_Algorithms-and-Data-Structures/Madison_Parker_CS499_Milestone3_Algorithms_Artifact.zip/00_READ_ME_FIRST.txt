MADISON PARKER - CS 499 MILESTONE THREE
Enhancement Two: Algorithms and Data Structures

This package contains the unchanged CS 320 source artifact from Module One and
the cumulative enhanced service suite. The enhanced snapshot retains the
software-design improvements and adds the Category Two search, filtering,
deterministic sorting, immutable results, and algorithm tests.

01_ORIGINAL_ARTIFACT_UNMODIFIED
    Exact copies of the 13 technical CS 320 baseline files included in Module One:
    12 Java source/test files and the portfolio reflection readme.

02_ENHANCED_ALGORITHMS_ARTIFACT
    Maven project containing the enhanced service suite and 103 JUnit test
    methods. Algorithm-specific behavior is located in the three service classes.

03_DOCUMENTATION
    Enhancement map, complexity and trade-off analysis, test plan, outcome
    crosswalk, progress log, and references.

04_EVIDENCE
    Standalone algorithm verification source, recorded results, original-file
    integrity hashes, and repeatable verification instructions.

Start with 03_DOCUMENTATION/ALGORITHM_COMPLEXITY_AND_TRADEOFFS.md.
The enhanced Maven project can be tested from its root with: mvn clean test
